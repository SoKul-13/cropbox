# SDHT
Class for DHT11, DHT12, DHT21, DHT22 sensors


Results are in tenths.


example:


celsius 217 = 21.7 degrees celsius

humidity 455 = 45.5% humidity


## TESTED ON

DHT11

DHT22

arduino uno

esp8266 D1 mini

attiny
